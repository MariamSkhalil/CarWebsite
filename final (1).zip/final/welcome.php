<html>
	<head>
	<style>
	body {
	background-image: url('img5.jpg');
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size: cover;
	}
	</style>
		<link rel="stylesheet" media="screen" href="bootstrap.min.css">

			<title>Home Page</title>


			<nav class="navbar navbar-expand-lg navbar-light bg-light ">

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav mr-auto">
					<a class="navbar-brand" href="#">
   						 <img src="carlogo.jpeg" width="60" height="40" alt="">
					</a>
						<li class="nav-item active">
							<a class="nav-link" href="reserve.php">For Booking <span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item active">
							<a class="nav-link" href="my_reservation.php">My Reservations/Return <span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
							<a  class="nav-link" href="logout.php">Logout</a>
						</li>

					</ul>
				</div>

			</nav>

	</head>

	<body class="modal-body">

		<div>
			<form action="welcome.php" method="post">
				<br><br><br>
				<h2 style="color:Khaki; text-align:center;font-style: oblique;font-stretch: 150%;font-size: xxx-large;">Welcome To Our Website</h2>

			</form>
		</div>
	</body>
</html>
